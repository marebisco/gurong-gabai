<style>
@keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
@keyframes blink { 0%,90%,100%{transform:scaleY(1)} 95%{transform:scaleY(0.1)} }
@keyframes shine { 0%{opacity:0;transform:translateX(-30px) rotate(-20deg)} 50%{opacity:0.7} 100%{opacity:0;transform:translateX(30px) rotate(-20deg)} }
@keyframes pulse { 0%,100%{opacity:0.3;transform:scale(0.95)} 50%{opacity:0.6;transform:scale(1.05)} }
@keyframes fadeUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
@keyframes hatBob { 0%,100%{transform:translateY(0) rotate(-2deg)} 50%{transform:translateY(-4px) rotate(2deg)} }
@keyframes starPop { 0%,100%{opacity:0;transform:scale(0)} 50%{opacity:1;transform:scale(1)} }
.logo-wrap { display:flex; flex-direction:column; align-items:center; justify-content:center; padding:40px 20px; gap:20px; }
.logo-anim { animation:float 3s ease-in-out infinite; display:flex; align-items:center; justify-content:center; position:relative; }
.hat { animation:hatBob 2.5s ease-in-out infinite; transform-origin:center bottom; }
.eyes { animation:blink 4s ease-in-out infinite; transform-origin:center; }
.shine { animation:shine 3s ease-in-out infinite 1s; }
.glow { animation:pulse 2s ease-in-out infinite; }
.star1{animation:starPop 2s ease-in-out infinite 0.3s}.star2{animation:starPop 2s ease-in-out infinite 0.9s}.star3{animation:starPop 2s ease-in-out infinite 1.5s}
.logo-text { text-align:center; animation:fadeUp 0.8s ease-out both; }
.logo-title { font-size:22px; font-weight:500; color:var(--text-primary); letter-spacing:0.5px; }
.logo-title span { color:#3b82f6; font-weight:500; }
.logo-tagline { font-size:13px; color:var(--text-secondary); margin-top:4px; font-style:italic; }
.logo-divider { width:60px; height:2px; background:linear-gradient(90deg,transparent,#3b82f6,transparent); margin:8px auto 0; border-radius:2px; }
</style>
<div class="logo-wrap">
  <div class="logo-anim">
    <svg width="120" height="130" viewBox="0 0 120 130" role="img" aria-label="Gurong GabAI animated logo">
      <ellipse class="glow" cx="60" cy="118" rx="28" ry="6" fill="#3b82f6" opacity="0.25"/>
      <rect x="18" y="36" width="84" height="76" rx="10" fill="#eff6ff" stroke="#3b82f6" stroke-width="2"/>
      <line x1="30" y1="62" x2="90" y2="62" stroke="#bfdbfe" stroke-width="2" stroke-linecap="round"/><line x1="30" y1="73" x2="80" y2="73" stroke="#bfdbfe" stroke-width="2" stroke-linecap="round"/><line x1="30" y1="84" x2="85" y2="84" stroke="#bfdbfe" stroke-width="2" stroke-linecap="round"/><line x1="30" y1="95" x2="72" y2="95" stroke="#bfdbfe" stroke-width="2" stroke-linecap="round"/>
      <g class="eyes"><ellipse cx="47" cy="52" rx="4" ry="4.5" fill="#1e40af"/><ellipse cx="73" cy="52" rx="4" ry="4.5" fill="#1e40af"/><circle cx="49" cy="50" r="1.2" fill="white"/><circle cx="75" cy="50" r="1.2" fill="white"/></g>
      <path d="M43 59 Q60 71 77 59" fill="none" stroke="#1e40af" stroke-width="2.5" stroke-linecap="round"/><ellipse cx="38" cy="58" rx="5" ry="3.5" fill="#fca5a5" opacity="0.5"/><ellipse cx="82" cy="58" rx="5" ry="3.5" fill="#fca5a5" opacity="0.5"/>
      <line class="shine" x1="30" y1="42" x2="38" y2="52" stroke="white" stroke-width="3" stroke-linecap="round" opacity="0"/>
      <g class="hat"><rect x="30" y="22" width="60" height="8" rx="2" fill="#1e3a8a"/><rect x="42" y="12" width="36" height="14" rx="3" fill="#1e3a8a"/><line x1="84" y1="26" x2="90" y2="36" stroke="#fbbf24" stroke-width="1.5"/><circle cx="90" cy="38" r="3" fill="#fbbf24"/><rect x="30" y="26" width="60" height="2" rx="1" fill="#fbbf24" opacity="0.6"/></g>
      <g class="star1"><text x="8" y="30" font-size="12" text-anchor="middle">&#10024;</text></g><g class="star2"><text x="112" y="48" font-size="10" text-anchor="middle">&#11088;</text></g><g class="star3"><text x="14" y="75" font-size="9" text-anchor="middle">&#10022;</text></g>
    </svg>
  </div>
  <div class="logo-text"><div class="logo-title">Gurong <span>GabAI</span></div><div class="logo-tagline">Ang AI na gumagabay sa bawat guro</div><div class="logo-divider"></div></div>
</div>