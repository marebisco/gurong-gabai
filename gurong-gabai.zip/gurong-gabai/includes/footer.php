<footer class="border-slate-200/80 px-4 py-4 text-center text-xs sm:px-7">
    <p>&copy; <?= date('Y') ?> Gurong GabAI. All rights reserved.</p>
</footer>
</body>
</html>